import Foundation
import CoreData

@objc(Meal)
public class Meal: NSManagedObject {

}
