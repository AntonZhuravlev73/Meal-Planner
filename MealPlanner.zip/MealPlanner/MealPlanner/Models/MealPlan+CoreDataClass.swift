import Foundation
import CoreData

@objc(MealPlan)
public class MealPlan: NSManagedObject {

}
