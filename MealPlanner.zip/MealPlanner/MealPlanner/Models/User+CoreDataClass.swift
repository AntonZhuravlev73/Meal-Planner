import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
